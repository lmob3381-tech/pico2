#!/usr/bin/env bash
# ==============================================================================
#  PicoClaw Termux 32-bit — Auto Cloud Builder via GitHub Actions (API Mode)
#  Menggunakan metode upload source_payload.zip via GitHub REST API (tanpa git push),
#  sehingga bebas dari error GitHub Push Protection (GH013).
# ==============================================================================
# Opsional: kosongkan agar ditanya setiap kali run, atau isi di sini
GITHUB_PAT="${GITHUB_PAT:-}"
GITHUB_REPO="${GITHUB_REPO:-}"
REPO_PRIVATE="${REPO_PRIVATE:-true}"
# ==============================================================================

set -euo pipefail

PREFIX="${PREFIX:-/data/data/com.termux/files/usr}"
INSTALL_DIR="${PREFIX}/bin"
export TMPDIR="${TMPDIR:-${PREFIX}/tmp}"
mkdir -p "$TMPDIR"

if [ -f "${PREFIX}/etc/tls/cert.pem" ] && [ -z "${SSL_CERT_FILE:-}" ]; then
  export SSL_CERT_FILE="${PREFIX}/etc/tls/cert.pem"
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Pastikan Python 3 & ca-certificates tersedia di Termux
MISSING_PKGS=()
command -v python3 >/dev/null 2>&1 || MISSING_PKGS+=(python)
[ -f "${PREFIX}/etc/tls/cert.pem" ] || MISSING_PKGS+=(ca-certificates)

if [ "${#MISSING_PKGS[@]}" -gt 0 ]; then
  if command -v pkg >/dev/null 2>&1; then
    echo "[*] Menginstall paket Termux yang kurang: ${MISSING_PKGS[*]}"
    pkg update -y && pkg install -y "${MISSING_PKGS[@]}"
  else
    echo "[ERROR] Paket belum terpasang: ${MISSING_PKGS[*]}" >&2
    exit 1
  fi
fi

# 2. Tanya PAT & nama repo jika belum diisi
echo ""
echo "=================================================="
echo "   PicoClaw Termux 32-bit Cloud Builder (API)"
echo "=================================================="

if [ -z "$GITHUB_PAT" ]; then
  read -r -s -p "Masukkan GitHub PAT (token): " GITHUB_PAT
  echo ""
fi
if [ -z "$GITHUB_PAT" ]; then
  echo "[ERROR] GitHub PAT tidak boleh kosong." >&2
  exit 1
fi

if [ -z "$GITHUB_REPO" ]; then
  read -r -p "Masukkan nama repo (contoh: pico2 atau user/pico2): " GITHUB_REPO
fi
GITHUB_REPO="$(echo "$GITHUB_REPO" | tr -d '[:space:]')"
if [ -z "$GITHUB_REPO" ]; then
  echo "[ERROR] Nama repo tidak boleh kosong." >&2
  exit 1
fi

export GITHUB_PAT GITHUB_REPO REPO_PRIVATE INSTALL_DIR SCRIPT_DIR

# 3. Jalankan engine upload ZIP + trigger GitHub Actions + download binary (metode tt.sh)
python3 - << 'PY_BUILDER_EOF'
import base64
import datetime
import json
import os
import platform
import shutil
import stat
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile

GITHUB_PAT = os.environ["GITHUB_PAT"].strip()
GITHUB_REPO = os.environ["GITHUB_REPO"].strip().strip("/")
REPO_PRIVATE = os.environ.get("REPO_PRIVATE", "true").lower() == "true"
INSTALL_DIR = os.environ["INSTALL_DIR"]
SCRIPT_DIR = os.environ["SCRIPT_DIR"]
WORKFLOW_FILENAME = "build-termux-32bit.yml"

WORKFLOW_YAML = """name: Build PicoClaw Termux 32-bit (ARMv7 & x86)

on:
  workflow_dispatch:

permissions:
  contents: read

jobs:
  build-termux-32bit:
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4

      - name: Extract Source Payload
        run: |
          mkdir -p "$RUNNER_TEMP/picoclaw_src"
          unzip -q -o source_payload.zip -d "$RUNNER_TEMP/picoclaw_src"
          ls -la "$RUNNER_TEMP/picoclaw_src"

      - name: Setup Go
        uses: actions/setup-go@v5
        with:
          go-version-file: ${{ runner.temp }}/picoclaw_src/go.mod
          cache: true

      - name: Generate Embedded Assets
        working-directory: ${{ runner.temp }}/picoclaw_src
        run: go generate ./...

      - name: Static Check (go vet 32-bit)
        working-directory: ${{ runner.temp }}/picoclaw_src
        run: |
          CGO_ENABLED=0 GOOS=linux GOARCH=arm GOARM=7 go vet -tags goolm,stdjson ./cmd/... ./pkg/...
          CGO_ENABLED=0 GOOS=android GOARCH=arm GOARM=7 go vet -tags stdjson ./cmd/... ./pkg/...

      - name: Compile PicoClaw 32-bit Binaries
        working-directory: ${{ runner.temp }}/picoclaw_src
        run: |
          mkdir -p "$RUNNER_TEMP/dist"
          CONFIG_PKG="github.com/sipeed/picoclaw/pkg/config"
          VERSION="termux32"
          COMMIT="${GITHUB_SHA::8}"
          BUILD_TIME="$(date -u +%FT%TZ)"
          GO_VER="$(go env GOVERSION)"
          LDFLAGS="-X ${CONFIG_PKG}.Version=${VERSION} -X ${CONFIG_PKG}.GitCommit=${COMMIT} -X ${CONFIG_PKG}.BuildTime=${BUILD_TIME} -X ${CONFIG_PKG}.GoVersion=${GO_VER} -s -w"

          # Recommended: static linux/arm GOARM=7 (runs on Termux 32-bit with full SQLite/Seahorse)
          CGO_ENABLED=0 GOOS=linux GOARCH=arm GOARM=7 \\
            go build -trimpath -tags goolm,stdjson -ldflags "$LDFLAGS" \\
            -o "$RUNNER_TEMP/dist/picoclaw-termux-armv7-static" ./cmd/picoclaw

          # Native android/arm GOARM=7
          CGO_ENABLED=0 GOOS=android GOARCH=arm GOARM=7 \\
            go build -trimpath -tags stdjson -ldflags "$LDFLAGS" \\
            -o "$RUNNER_TEMP/dist/picoclaw-android-arm" ./cmd/picoclaw

          # Static linux/386 (for x86 32-bit Termux)
          CGO_ENABLED=0 GOOS=linux GOARCH=386 \\
            go build -trimpath -tags goolm,stdjson -ldflags "$LDFLAGS" \\
            -o "$RUNNER_TEMP/dist/picoclaw-termux-386-static" ./cmd/picoclaw

          chmod +x "$RUNNER_TEMP/dist/"picoclaw-*
          ls -lh "$RUNNER_TEMP/dist/"

      - name: Upload Termux 32-bit Artifact
        uses: actions/upload-artifact@v4
        with:
          name: picoclaw-termux-32bit
          path: ${{ runner.temp }}/dist/picoclaw-*
          if-no-files-found: error
          retention-days: 7
"""


def api_req(method, path, body=None, timeout=60):
    url = path if path.startswith("http") else f"https://api.github.com{path}"
    headers = {
        "Authorization": f"Bearer {GITHUB_PAT}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "picoclaw-termux32-builder",
    }
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            if not raw:
                return resp.status, {}
            try:
                return resp.status, json.loads(raw.decode("utf-8"))
            except Exception:
                return resp.status, raw
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except Exception:
            parsed = {"message": raw.decode("utf-8", errors="ignore")}
        return e.code, parsed


def put_repo_file(owner, repo, branch, repo_path, content_bytes, message):
    endpoint = f"/repos/{owner}/{repo}/contents/{repo_path}"
    st, info = api_req("GET", f"{endpoint}?ref={branch}")
    sha = info.get("sha") if st == 200 and isinstance(info, dict) else None
    payload = {
        "message": message,
        "content": base64.b64encode(content_bytes).decode("ascii"),
        "branch": branch,
    }
    if sha:
        payload["sha"] = sha
    put_st, put_resp = api_req("PUT", endpoint, payload, timeout=180)
    if put_st not in (200, 201):
        print(f"[ERROR] Gagal upload '{repo_path}' (HTTP {put_st}): {put_resp}", file=sys.stderr)
        sys.exit(1)


def pack_source_payload(src_root):
    skip_dirs = {
        ".git", "docs", "assets", "examples", "docker",
        "build", "dist", "node_modules", ".cache", "__pycache__",
    }
    tmp_fd, tmp_zip = tempfile.mkstemp(prefix="picoclaw_payload_", suffix=".zip")
    os.close(tmp_fd)
    file_count = 0
    with zipfile.ZipFile(tmp_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for root, dirs, files in os.walk(src_root):
            rel_root = os.path.relpath(root, src_root)
            dirs[:] = [
                d for d in dirs
                if d not in skip_dirs and not (rel_root == "web" and d == "frontend")
            ]
            for fn in files:
                if fn.endswith(".zip") or fn in (".DS_Store", "Thumbs.db"):
                    continue
                full = os.path.join(root, fn)
                arc = os.path.relpath(full, src_root)
                zf.write(full, arc)
                file_count += 1
    return tmp_zip, file_count, os.path.getsize(tmp_zip)


def main():
    # 1. Verifikasi PAT & ambil username
    print("[*] Memverifikasi GitHub PAT...")
    st, user_info = api_req("GET", "/user")
    gh_user = user_info.get("login", "") if st == 200 else ""
    if not gh_user:
        print(f"[ERROR] PAT tidak valid (HTTP {st}): {user_info}", file=sys.stderr)
        sys.exit(1)
    print(f"[OK] Login sebagai: {gh_user}")

    if "/" in GITHUB_REPO:
        owner, repo = GITHUB_REPO.split("/", 1)
    else:
        owner, repo = gh_user, GITHUB_REPO
    full_repo = f"{owner}/{repo}"

    # 2. Cek repo (auto-create jika belum ada, langsung pakai jika sudah ada)
    print(f"[*] Memeriksa repo {full_repo}...")
    st, repo_info = api_req("GET", f"/repos/{full_repo}")
    if st == 200:
        branch = repo_info.get("default_branch") or "main"
        print(f"[OK] Repo {full_repo} sudah ada (branch: {branch}).")
    elif st == 404:
        print(f"[*] Repo {full_repo} belum ada. Membuat repo baru otomatis...")
        create_ep = "/user/repos" if owner == gh_user else f"/orgs/{owner}/repos"
        cst, cresp = api_req("POST", create_ep, {
            "name": repo,
            "description": "PicoClaw Termux 32-bit Cloud Builder",
            "private": REPO_PRIVATE,
            "auto_init": True,
        })
        if cst not in (200, 201):
            print(f"[ERROR] Gagal membuat repo (HTTP {cst}): {cresp}", file=sys.stderr)
            sys.exit(1)
        branch = cresp.get("default_branch") or "main"
        print(f"[OK] Repo baru dibuat: {cresp.get('full_name')} (branch: {branch})")
        time.sleep(2)
    else:
        print(f"[ERROR] Gagal mengakses repo {full_repo} (HTTP {st}): {repo_info}", file=sys.stderr)
        sys.exit(1)

    # 3. Upload workflow file via Contents API
    print(f"[*] Menyiapkan workflow .github/workflows/{WORKFLOW_FILENAME}...")
    put_repo_file(
        owner, repo, branch,
        f".github/workflows/{WORKFLOW_FILENAME}",
        WORKFLOW_YAML.encode("utf-8"),
        f"ci: setup {WORKFLOW_FILENAME}",
    )
    print("[OK] Workflow siap.")

    # 4. Pack source_payload.zip (tanpa docs/assets/.git -> ~2.3MB & bebas GH013 secret scanning!)
    print("[*] Mengemas source code ke source_payload.zip (bebas push protection)...")
    payload_zip, file_count, zip_size = pack_source_payload(SCRIPT_DIR)
    try:
        print(f"[*] Mengunggah source_payload.zip ({file_count} file, {zip_size / (1024 * 1024):.2f} MB)...")
        with open(payload_zip, "rb") as f:
            zip_bytes = f.read()
        put_repo_file(
            owner, repo, branch,
            "source_payload.zip",
            zip_bytes,
            f"build: upload picoclaw source payload ({datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})",
        )
        print("[OK] source_payload.zip berhasil diunggah.")
    finally:
        if os.path.exists(payload_zip):
            os.remove(payload_zip)

    # 5. Catat run lama lalu trigger workflow_dispatch
    runs_ep = f"/repos/{full_repo}/actions/workflows/{WORKFLOW_FILENAME}/runs?per_page=5"
    _, prev_runs_resp = api_req("GET", runs_ep)
    prev_ids = {r.get("id") for r in (prev_runs_resp.get("workflow_runs") or [])}

    print("[*] Memicu GitHub Actions build 32-bit...")
    time.sleep(2)
    dst, dresp = api_req(
        "POST",
        f"/repos/{full_repo}/actions/workflows/{WORKFLOW_FILENAME}/dispatches",
        {"ref": branch},
    )
    if dst not in (200, 201, 204):
        print(f"[ERROR] Gagal memicu workflow (HTTP {dst}): {dresp}", file=sys.stderr)
        print("Pastikan GitHub PAT memiliki izin (scope) 'repo' dan 'workflow'.", file=sys.stderr)
        sys.exit(1)

    # 6. Tunggu Run ID muncul
    print("[*] Menunggu antrean runner GitHub Actions...")
    run_id = None
    run_url = ""
    for _ in range(25):
        time.sleep(3)
        rst, rdata = api_req("GET", runs_ep)
        if rst == 200:
            for r in rdata.get("workflow_runs") or []:
                rid = r.get("id")
                if rid and rid not in prev_ids:
                    run_id = rid
                    run_url = r.get("html_url", "")
                    break
        if run_id:
            break

    if not run_id:
        print(f"[ERROR] Timeout menunggu Run ID. Cek manual: https://github.com/{full_repo}/actions", file=sys.stderr)
        sys.exit(1)

    print(f"[OK] Build berjalan (Run #{run_id})")
    print(f"     Link: {run_url}")

    # 7. Pantau progres & step aktif (seperti tt.sh)
    start_ts = time.time()
    last_msg = ""
    conclusion = ""
    while True:
        st, rinfo = api_req("GET", f"/repos/{full_repo}/actions/runs/{run_id}")
        status = rinfo.get("status", "") if st == 200 else ""
        conclusion = rinfo.get("conclusion") or ""

        step_name = ""
        jst, jinfo = api_req("GET", f"/repos/{full_repo}/actions/runs/{run_id}/jobs")
        if jst == 200:
            jobs = jinfo.get("jobs") or []
            if jobs:
                for step in jobs[0].get("steps") or []:
                    if step.get("status") == "in_progress":
                        step_name = step.get("name", "")
                        break

        elapsed = int(time.time() - start_ts)
        mins, secs = divmod(elapsed, 60)
        msg = f"[*] [{mins:02d}:{secs:02d}] Status: {status}" + (f" | Step: {step_name}" if step_name else "")
        if msg != last_msg:
            print(msg)
            last_msg = msg

        if status == "completed":
            break
        time.sleep(6)

    if conclusion != "success":
        print(f"[ERROR] Build gagal di GitHub Actions (conclusion: {conclusion})!", file=sys.stderr)
        print(f"        Cek log detail di: {run_url}", file=sys.stderr)
        sys.exit(1)

    print("[OK] Build GitHub Actions BERHASIL!")

    # 8. Download artifact & install ke $PREFIX/bin/picoclaw
    print("[*] Mengunduh hasil compile (picoclaw-termux-32bit)...")
    ast, ainfo = api_req("GET", f"/repos/{full_repo}/actions/runs/{run_id}/artifacts")
    arts = ainfo.get("artifacts") or [] if ast == 200 else []
    target = next((a for a in arts if a.get("name") == "picoclaw-termux-32bit"), arts[0] if arts else None)
    if not target or not target.get("archive_download_url"):
        print(f"[ERROR] Artifact tidak ditemukan. Cek manual di: {run_url}", file=sys.stderr)
        sys.exit(1)

    dl_url = target["archive_download_url"]
    req = urllib.request.Request(
        dl_url,
        headers={
            "Authorization": f"Bearer {GITHUB_PAT}",
            "Accept": "application/vnd.github+json",
            "User-Agent": "picoclaw-termux32-builder",
        },
    )
    art_zip = os.path.join(os.environ.get("TMPDIR", "/tmp"), f"picoclaw_art_{run_id}.zip")
    with urllib.request.urlopen(req, timeout=180) as resp, open(art_zip, "wb") as out_f:
        shutil.copyfileobj(resp, out_f)

    dist_dir = os.path.join(SCRIPT_DIR, "dist")
    os.makedirs(dist_dir, exist_ok=True)
    with zipfile.ZipFile(art_zip, "r") as zf:
        zf.extractall(dist_dir)
    os.remove(art_zip)

    arch = platform.machine().lower()
    if arch in ("i686", "i386", "x86"):
        picked = os.path.join(dist_dir, "picoclaw-termux-386-static")
    else:
        picked = os.path.join(dist_dir, "picoclaw-termux-armv7-static")

    if not os.path.isfile(picked):
        print(f"[ERROR] Binary {picked} tidak ditemukan di ./dist/", file=sys.stderr)
        sys.exit(1)

    os.makedirs(INSTALL_DIR, exist_ok=True)
    tmp_dst = os.path.join(INSTALL_DIR, "picoclaw.new")
    final_dst = os.path.join(INSTALL_DIR, "picoclaw")
    shutil.copy2(picked, tmp_dst)
    os.chmod(tmp_dst, os.stat(tmp_dst).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    os.replace(tmp_dst, final_dst)

    print("")
    print(f"[OK] PicoClaw 32-bit berhasil di-install ke: {final_dst}")
    print(f"[OK] Semua varian binary juga tersimpan di: {dist_dir}")
    print("")


if __name__ == "__main__":
    main()
PY_BUILDER_EOF

echo "=== Verifikasi ==="
"${INSTALL_DIR}/picoclaw" version || true
echo ""
echo "Jalankan 'picoclaw onboard' untuk mulai konfigurasi."
